This zip includes:
 -> The excel file created to make the graphics for the report
 -> The csv files generated from the genetic algorithm
 -> The csv files generated from the genetic algorithm and used for make the reports
 -> The code developed for the assignment
 -> The report of the assignment

